 <form class="form_inline" action="<?php echo site_url("front/search") ?>" method="get" accept-charset="utf-8">
  <div class="controls">
    <input type="text" name="query" placeholder="pencarian cepat" class="span12 searchbar">
    </div>
  </form>
  <div id="blog">
  <table class="data-table table">
  <thead><tr><td>Berita Terkini</td></tr></thead>
  <tbody>
   <tr>
    <td colspan="5" class="dataTables_empty">Loading data..</td>
  </tr>
  </tbody>
  </table>
  </div>
