<h3>Basic Application Point Of Sales</h3>
    <hr class="new"/>
    <p>Aplikasi dasar untuk menangani proses penjualan yang meliputi fasilitas :</p>
      <ol>
        <li>Master Data Satuan</li>
        <li>Master Data Lokasi</li>
        <li>Master Data Kategori</li>
        <li>Master Data Barang</li>
        <li>Master Data User</li>
        <li>Master Data Customer</li>
        <li>Master Data Suppllier</li>
        <li>Transaksi Penjualan
            <ul>
              <li>Penjualan Customer</li>
              <li>Penjualan Point / diskon</li>
              <li>Penjualan Distributor</li>
            </ul>
        </li>
        <li>Transaksi Pembelian</li>
        <li>Transaksi Retur</li>
        <li>Transaksi PreOrder</li>
        <li>Laporan Stok Barang</li>
        <li>Laporan Penjualan</li>
        <li>Laporan Pembelian</li>
        <li>Laporan Retur</li>
        <li>Laporan Grafik Penjualan</li>
        <li>Laporan Laba Rugi</li>
        <li>Hak Akses Module</li>
        <li>Setting Application</li>
      </ol>