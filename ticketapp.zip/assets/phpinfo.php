<?php echo phpinfo(); ?>
