
<div class="span6">
<div class="span12">
<div class="widget-box">
  <div class="widget-title">
    <span class="icon"><i class="icon-th-list"></i></span>
    <h5>Replay Answer</h5>
  </div>
  <div class="widget-content">
  <?php
  $date = ($detail->update == '0000-00-00' || is_null($detail->update)) ? "Post : ".datetimes($detail->date) : " update ".datetimes($detail->update);
  ?>
  <h4><i class='moon-bookmark'></i> <?=$detail->title?></h4>
  <div class='postdate'><?=$date?> status : <?=$detail->status?></div>
  <span class='author-pesan text-error'><i class='moon-user-4'></i> <strong>from : <?=$detail->full_name?></strong></span>
  <p><?=$detail->question?></p>
  <hr>
  <?php
  if($detail->file_name != "")
    echo "klik untuk mendownload file <a class='text-error' href='".site_url("attachment")."/$detail->file_name_encrypt'>$detail->file_name</a>";
  ?>
</div>
<?php if($this->session->userdata('tipe') != '1'): ?>
<form class="form-horizontal" method="post" action="<?=site_url('replay_ticket/change_status')?>">
<div class="control-group">
  <label class="control-label">Status</label>
<div class="controls">
  <input type="hidden" name="id" value="<?=$id?>">
  <select name="status_id" data-tag="select" class="select2 span5">
     <?php
        foreach($status->result() as $list){
          echo "<option value='$list->status_id'>$list->status</option>";
        }
      ?>
  </select> <button type="submit" class="btn btn-success">Update</button>
</div>
</div>
</form>
<?php endif; ?>
</div>
</div>

<?php if($answer): ?>
  <?php foreach ($answer as $list):?>
<div class="clearcol"></div>
<div class="span12 normal-margin">
<div class="widget-box">
  <div class="widget-title">
    <span class="icon"><i class="icon-th-list"></i></span>
    <h5>Answer <?=$list->full_name  ?> date <?=datetimes($list->date)  ?></h5>
  </div>
  <div class="widget-content">
    <p><?=$list->answer?></p>
    <hr>
    <?php
      if($list->user_uuid == $this->session->userdata('userid')){
        echo "<a class='btn btn-inverse' data-uuid='$list->auuid' href='".site_url("replay_ticket/del_answer/".$list->auuid)."'>delete</a>";
      }
    ?>
  </div>
</div>
</div>
<?php endforeach; ?>
<?php endif; ?>
<?php if($this->session->userdata('tipe') == '0' || $detail->status == "open"): ?>
<div class="clearcol"></div>
<div class="span12 normal-margin">
<div class="widget-box">
  <div class="widget-title">
    <span class="icon"><i class="icon-th-list"></i></span>
    <h5>Form Answer</h5>
  </div>
  <div class="widget-content">
    <form class="form-horizontal" method="post" action="<?=site_url('replay_ticket/save_answer')?>">
      <input type="hidden" name="ticket_id" value="<?=$id?>">
      <textarea name="answer" id='textarea' style="width: 100%;" placeholder="answer here"></textarea>
      <br>
      <button type="submit" class="btn btn-primary">Answer</button> <button type="button" class="btn btn-warning">Assign</button>
    </form>
  </div>
</div>
</div>
<?php endif; ?>
</div>
<?php if($this->session->userdata('tipe') != '1'): ?>
<div class="span6">
  <div class="span6">
<div class="widget-box">
  <div class="widget-title">
    <span class="icon"><i class="icon-th-list"></i></span>
    <h5>Assign Ticket</h5>
  </div>
  <div class="widget-content">
  <?php
   if($this->session->flashdata('msg')){
    echo $this->session->flashdata('msg');
   }
  ?>
  <form class="form-horizontal" action="<?=site_url("replay_ticket/save_assign_operator")?>" method="post">
  <input type="hidden" name="uuid" value="<?=$id?>">
  <ul class="nav nav-list">
      <li class="nav-header">Departement</li>
      <?php
        foreach ($departement as $list) {
          echo "<li>
          <a href='#' class='filter' data-deptid='$list->departement_id' data-status='-'><strong>
          $list->departement_name</strong></a>";
          foreach ($this->replay_ticket->get_operator($list->departement_id) as $val) {
            if($detail->operator_uuid == $val->uuid){
              echo "<li><label class='radio' for='radio'><input type='radio' checked name='operator_uuid' value='$val->uuid'>$val->full_name</label></li>";
            }else
            echo "<li><label class='radio' for='radio'><input type='radio' name='operator_uuid' value='$val->uuid'>$val->full_name</label></li>";
          }
          echo "</li>";
        }
      ?>
    </ul>
    <hr>
    <button type="submit" class='btn btn-primary'>Assign Ticket</button>
    </form>
  </div>
  </div>
  </div>
  <div class="span6">
<div class="widget-box">
  <div class="widget-title">
    <span class="icon"><i class="icon-th-list"></i></span>
    <h5>History Ticket</h5>
  </div>
  <div class="widget-content">
  <table class="table table-condensed table-hover table-striped">
    <thead>
      <tr>
        <th>NO</th>
        <th>STATUS</th>
        <th>NEW DEPARTEMENT</th>
        <th>DATE</th>
        <th>OPERATOR</th>
      </tr>
    </thead>
    <tbody>
      <?php
      $no=0;
      foreach ($history as $list) {
        $no++;
        echo "<tr>
          <td>$no</td>
          <td>$list->status</td>
          <td>$list->new_departement</td>
          <td>".datetimes($list->date)."</td>
          <td>$list->full_name</td>
        </tr>";
      }
      ?>
    </tbody>
  </table>
  </div>
  </div>
  </div>
</div>
</div>
<?php endif; ?>

<style type="text/css" media="screen">
  label.radio{
    cursor: hand;
  }
  label.radio:hover{
      background-color: #eee;
  }
</style>
<script type="text/javascript">
  $(document).ready(function(){
    $("label.radio").click(function(){
      $(this).find("input").prop('checked',true);
    });
  });
</script>
